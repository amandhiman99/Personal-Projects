// Using API from openweathermap.org

 async function getWeatherInfor(){

  const APIKey = "7a3699270e07b587e85df1c155263464";
  const cityName = document.getElementById("text").value;
  let APILink = "https://api.openweathermap.org/data/2.5/weather?q=" + cityName +"&units=metric&appid=" + APIKey;
        
        
  const data = await fetch(APILink,{method:"GET"})
  const JSON = await data.json();
    if(JSON){
      console.log("success");
    }
    else {
      console.error("no Data");
    }
    console.log(JSON);
    console.log(JSON.weather[0]);
    console.log(JSON.main);
        
//Creating HTML elements
        
    const div = document.createElement("div");
    const pMain = document.createElement("p");
    const pDescription = document.createElement("p");
    const pTemp = document.createElement("p");
    const getWeather = document.getElementById("getWeather");
    const city = document.createElement("h1");
        
//Printitng data to the created HTML elements
        
  city.appendChild(document.createTextNode("Weather of " + cityName));
  pMain.appendChild(document.createTextNode("Weather: " + JSON.weather[0].main));
  pDescription.appendChild(document.createTextNode("Description: " + JSON.weather[0].description));
  pTemp.appendChild(document.createTextNode("Temperature: " + JSON.main.temp +"℃"));
  div.appendChild(city);
  div.appendChild(pMain);
  div.appendChild(pDescription);
  div.appendChild(pTemp);
  getWeather.appendChild(div);
}
        
        
// Weather Search Button
const weatherBtn = document.getElementById("weatherBtn");
  if(weatherBtn){
    weatherBtn.addEventListener("click", () => {
      getWeatherInfor();
    });
  }





// Getting  Radio Button values from the BVC Sports form 

  function getValue() {
    let valueRadioBtn ="";
      let value = document.getElementsByName('Status');
      for( let i = 0 ; i < value.length; i++ )
      {
          if(value[i].checked)
          {
            valueRadioBtn=value[i].value;
            console.log(value[i].value);
            break;
          }
      }
      return valueRadioBtn;
   
  }

  // Registration Fee Details
  function registrationFeeDetails(){
      
          const details = getValue();
          const fee = document.getElementById("feeDescription");
          const ID = document.getElementById("ID").value;
          const fullName = document.getElementById("fName").value;
          const address = document.getElementById("address").value;
          const p = document.createElement("p");
          try{
          // Empty Value
          if(details == ""|| ID == "" || fullName == "" || address =="") throw "Please Enter all the fields";
           
          
          //For student
          
        if(details =="Student") {
              p.appendChild(document.createTextNode("Your registration fee as a student is 10$"));
              fee.appendChild(p);
          }

          //For Staff

        if(details == "Staff"){
              p.appendChild(document.createTextNode("Your registration fee as a staff member is 50$"));
              fee.appendChild(p);
          }

          //For Volunteer

        if(details== "Volunteer"){
              p.appendChild(document.createTextNode("Your registration fee as a volunteer is 0$"));
              fee.appendChild(p);
          }
        }
        catch(error){
            p.appendChild(document.createTextNode(error));
            fee.appendChild(p);
        }
      
      
  }


  // Posting the Values to Webpage and pushing the values to  /data route
  async function pushValue(){
      let ID = document.getElementById("ID").value;
      let fullName = document.getElementById("fName").value;
      let address = document.getElementById("address").value;
      let value =  getValue('Status');
   console.log(value);
      let data = new URLSearchParams();

      data.append("ID",ID);
      data.append("fullName",fullName);
      data.append("address",address);
      data.append("status",value);

      const reply = await fetch ("/data",{method:"POST",body:data});
      const JSON = await reply.json();

      const registeredDetails = document.getElementById("details");
      const div = document.createElement("div");
      const p = document.createElement("p");
      const pID = document.createElement("p");
      const pName = document.createElement("p");
      const pAddress = document.createElement("p");
      const pStatus = document.createElement("p");
      console.log(ID);

  p.appendChild(document.createTextNode("You are succefully registered! Details of your Registration: "));
  pID.appendChild(document.createTextNode("ID: " + ID));
  pName.appendChild(document.createTextNode("Full Name: "+ fullName));
  pAddress.appendChild(document.createTextNode("Address: " + address));
  pStatus.appendChild(document.createTextNode("Status: " + value));
  registeredDetails.appendChild(p);
  registeredDetails.appendChild(pID);
  registeredDetails.appendChild(pName);
  registeredDetails.appendChild(pAddress);
  registeredDetails.appendChild(pStatus);
  registeredDetails.appendChild(div);


}

// Fee Details Button
const feeDetails = document.getElementById("feeDetails");
if(feeDetails){
feeDetails.addEventListener("click", () => {
      getValue();
      registrationFeeDetails();

});
}

// Registration Button
const register = document.getElementById("register");
if(register){
register.addEventListener("click", () =>{
  pushValue();
});
}


