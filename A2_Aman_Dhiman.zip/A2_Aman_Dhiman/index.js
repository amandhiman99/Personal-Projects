const express = require("express");
const bodyparser = require("body-parser"); // Using Body parser
const fs = require("fs"); // Using file systems
const path = require("path"); // using path directory

const PORT = 3000; // Using the PORT

const app = express(); 

// Static CSS and JavaScript files 
app.use(express.static('style'));
app.use(express.static('script'));
app.use(bodyparser.urlencoded({extended:false}));

// Home Route 
app.get("/", (req,res) => {
    res.sendFile(path.join(__dirname,"/Weather.html"));
    
});

// Route for Weather Page
app.get("/Weather.html", (req,res) => {
    res.sendFile(path.join(__dirname,"/Weather.html"));
    
});


// Sports Page Route
app.get("/BVCSport.html", (req,res) => {
    res.sendFile(path.join(__dirname,"/BVCSport.html"));
});


// Posting data to data.json
app.post("/data",(request,response) => {
    const ID = request.body.ID;
    const fullName = request.body.fullName;
    const address  = request.body.address;
    const value = request.body.status;
    console.log(request.body.status);


    console.log(ID,fullName,address,value);
    if(ID == "" || fullName =="" || address==""||value==""){
     console.log("Must provide data");
     
     

    }
    else{
    let valueArray =[];
    try{
        valueArray = JSON.parse(fs.readFileSync("./data.json","utf-8"));
        valueArray.values.push({ID:ID, Fullname:fullName,Address:address,Status:value});
        fs.writeFileSync("./data.json",JSON.stringify(valueArray));
    }
    catch{

    }

    response.send(JSON.stringify(valueArray));
}
});
app.get('/data.html', (req,res) => {
    res.sendFile(path.join(__dirname,'/data.json'));
});

app.listen(PORT, () => {
    console.log(`API starting at ${PORT}`);
});