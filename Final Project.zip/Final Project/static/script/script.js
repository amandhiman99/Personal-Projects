const date = new Date();
const year = document.getElementById('year');

const span = document.createElement('span');
span.appendChild(document.createTextNode(date.getUTCFullYear()));
year.appendChild(span);


  
    const scrollDownbtn= document.getElementById('scroll');
  
    function scrollDown() {
      let windowCoords = document.documentElement.clientHeight;
      (function scroll() {
          
        if (window.pageYOffset <= windowCoords) {
          window.scrollBy(0, 10);
          setTimeout(scroll,0);
        }
        if (window.pageYOffset > windowCoords) {
          window.scrollTo(0, windowCoords);
        }
      
      })();
    }

    if(scrollDownbtn)
    scrollDownbtn.addEventListener('click', scrollDown);


    function getValues(){
      const fname = document.getElementById('fname').value;
      const lname = document.getElementById('lname').value;
      const number = document.getElementById('number').value;
      const email = document.getElementById('email').value;
      const service = document.getElementById('services').value;
      const message = document.getElementById('message').value;

      console.log(service);

      const msg = document.getElementById('msg');

      const p =document.createElement('p');

      try{
        if(fname == "" || lname == ""|| number == "" ||email == "" ||message =="") throw "Enter valid Values"

        else{
          p.appendChild(document.createTextNode(" Hey! we got your Message. Our Customer Service team will contact you shortly on your email: " + email + " or Phone Number: " + number))
          msg.appendChild(p);
        }
      }
      catch(err){
        p.appendChild(document.createTextNode(err));
        msg.appendChild(p);
      }
    }


    async function pushValue(){
      let fname = document.getElementById('fname').value;
      let lname = document.getElementById('lname').value;
      let number = document.getElementById('number').value;
      let email = document.getElementById('email').value;
      let service = document.getElementById('services').value;
      let message = document.getElementById('message').value;

      console.log(service);

      let data = new URLSearchParams();

      data.append("fname", fname);
      data.append("lname", lname);
      data.append("number", number);
      data.append("email", email);
      data.append("service", service);
      data.append("message", message);

      console.log(data);

      const reply = await fetch("/data", {method:"POST", body:data});

      const JSON = await reply.json();
    }

    
    const submitBtn = document.getElementById("submit");
    if(submitBtn){
    submitBtn.addEventListener("click", () => {
      getValues();
      pushValue();
    });
  }
  