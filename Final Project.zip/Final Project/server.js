const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const PORT = 3000;

const app = express();

app.set('views', path.join(__dirname,'views'));
app.set('view engine', 'pug')

app.use(express.static('static'));
app.use(bodyParser.urlencoded({extended:false}));

app.get('/', (req,res) => {
    res.render(path.join(__dirname,"/views/index.pug"));
});

app.get( '/index.pug', (req,res) => {
    res.render(path.join(__dirname,"/views/index.pug"));
});

app.get('/services.pug', (req,res) => {
    res.render(path.join(__dirname,"/views/services.pug"));
});

app.get('/portfolio.pug', (req,res) => {
    res.render(path.join(__dirname,"/views/portfolio.pug"));
});

app.get('/contact.pug', (req,res) => {
    res.render(path.join(__dirname,"/views/contact.pug"));
});


app.post("/data", (req,res) => {
    const fname = req.body.fname;
    const lname = req.body.lname;
    const number = req.body.number;
    const email = req.body.email;
    const service = req.body.service;
    const message = req.body.message;

    console.log(fname, lname, number, email, service, message);

    if(fname == "" || lname == "" || number == "" || email == "" || service == "" || message == ""){
        console.log("Provide appropriate data")
    }

    else {
        let detailsArray = [];

        try{
            detailsArray = JSON.parse(fs.readFileSync("./data.json", "utf-8"));

            detailsArray.Details.push({fname:fname, lname:lname, number: number, email:email, service:service, message:message});


            fs.writeFileSync("./data.json", JSON.stringify(detailsArray));
        }

            catch{

                }

                res.send(JSON.stringify(detailsArray));
        }
    });

app.get("/data", (req,res) => {
    res.render(path.join(__dirname, "/data.json"));
});



app.listen(PORT, () => {
    console.log(`App starting on ${PORT}`);
});
